package wde.commandlinerunnerdemo;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component // WICHTIG: Sagt Spring, dass diese Klasse als Bean verwaltet und beim Start beachtet werden soll
public class DataInitializerLsg implements CommandLineRunner {

    // Das Repository wird per Constructor Injection eingebunden
    private final ProductRepository productRepository;


    public DataInitializerLsg(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("===========================================");
        System.out.println("Starte Daten-Initialisierung...");

        // Produkte erstellen und nacheinander speichern
        Product p1 = new Product("Laptop", 999.99);
        productRepository.save(p1);
        System.out.println("Eingefuegt: " + p1.getName());

        Product p2 = new Product("Mouse", 29.99);
        productRepository.save(p2);
        System.out.println("Eingefuegt: " + p2.getName());

        Product p3 = new Product("Keyboard", 79.99);
        productRepository.save(p3);
        System.out.println("Eingefuegt: " + p3.getName());

        System.out.println("Alle Produkte erfolgreich in die DB geladen!");
        System.out.println("===========================================");
    }
}