package wde.commandlinerunnerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommandLineRunnerDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
