package wde.waehrungsrechner_spring.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import wde.waehrungsrechner_spring.dto.ConversionDTO;
import wde.waehrungsrechner_spring.service.CurrencyService;

// HIER: Definition RESTController und des Basispfads
public class CurrencyController {

    private final CurrencyService currencyService;

    public CurrencyController(CurrencyService currencyService) {
        this.currencyService = currencyService;
    }
	
	
    // HIER: Annotation, um auf GET-Mapping /convert zu reagieren
    public ResponseEntity<?> convert() {
		// Hier implementieren
        
    }
}