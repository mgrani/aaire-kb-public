package wde.waehrungsrechner_spring.service;

import org.springframework.stereotype.Service;
import wde.waehrungsrechner_spring.dto.ConversionDTO;
import wde.waehrungsrechner_spring.entity.ExchangeRate;
import wde.waehrungsrechner_spring.repository.ExchangeRateRepository;

import java.util.Optional;

// HIER: Annotation
public class CurrencyService {

    // HIER: Attribut und Dependency Injection via Konstuktor
	// ...

    public ConversionDTO convert(Double amount, String targetCurrency) {

        // HIER:
		// Zugriff auf die Datenbank zum Abruf des Wechselkurses via Repository
		// ...
		
		
		
        ExchangeRate rate;
		// Auslesen des Wechselkurses aus dem Ergebnis des Datenbankzugriffs (Optional-Objekt)
        // ....
		

		// Bestimmung des Rückgabewerts: Falls rate null, Rückgabe null
		// Andernfalls Berechnung des umgerechneten Betrags mit Hife des Wechselkurses und
		// Befüllung eines ConversionDTOs für die Rückgabe
        // ....
    }
}