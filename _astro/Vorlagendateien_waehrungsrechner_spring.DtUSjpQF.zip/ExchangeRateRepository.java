package wde.waehrungsrechner_spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import wde.waehrungsrechner_spring.entity.ExchangeRate;

import java.util.Optional;

public interface ExchangeRateRepository
        extends JpaRepository<ExchangeRate, Long> {

    Optional<ExchangeRate> ________________________(String currency);

}