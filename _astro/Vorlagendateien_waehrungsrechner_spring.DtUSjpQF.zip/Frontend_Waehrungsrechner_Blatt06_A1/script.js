const amountEl = document.getElementById('amount');
const currencyEl = document.getElementById('targetCurrency');
const resultEl = document.getElementById('result');


// --- START: Hier ergänzen (Lösung) ---
async function convert() {
    const amount = amountEl.value;
    const target = currencyEl.value;

    if (!amount || amount <= 0) {
        resultEl.innerText = "Bitte Betrag eingeben";
        return;
    }
    
    try {
        const url = `https://api.frankfurter.dev/v1/latest?amount=${amount}&from=EUR&to=${target}`;
        
        const response = await fetch(url);
        
        if (!response.ok) throw new Error("API Fehler");

        const data = await response.json();
        
        // Das Ergebnis steht in data.rates[target], siehe API Doku
        const convertedValue = data.rates[target];

        resultEl.innerHTML = `${amount} EUR = ${convertedValue.toFixed(2)} ${target}`;
    } catch (error) {
        resultEl.innerText = "Fehler beim Laden der Daten.";
    }
    // --- ENDE ---
}

// --- START: ---
// Event-Listener für automatische Aktualisierung
amountEl.addEventListener('input', convert);
currencyEl.addEventListener('change', convert);
// --- ENDE ---