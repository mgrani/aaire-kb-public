# Live-Demo: IP- & Cookie-Schutz (WDE)

Diese Minimalanwendung demonstriert, wie zustandslose REST-APIs ohne vollwertiges Authentifizierungssystem 
(wie Spring Security) gegen einfachen Missbrauch (z. B. Mehrfachabstimmungen) geschützt werden können.