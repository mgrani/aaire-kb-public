package wde.democookieip;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.Set;

@SpringBootApplication
@RestController
@RequestMapping("/api/demo")
public class DemoCookieIpApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoCookieIpApplication.class, args);
    }

    // In-Memory "Datenbank": Speichert Kombinationen aus "IP_ITEM-ID"
    private final Set<String> voteDatabase = new HashSet<>();

    @PostMapping("/vote/{itemId}")
    public ResponseEntity<String> submitVote(
            @PathVariable Long itemId,
            HttpServletRequest request,
            @CookieValue(value = "voted_items", defaultValue = "") String votedCookie) {

        // 1. IP-Adresse auslesen
        String clientIp = request.getRemoteAddr();

        String ipVoteKey = clientIp + "_" + itemId;

        // 2. Schutz-Pruefung (Cookie ODER IP)
        boolean hasCookie = votedCookie.contains("[" + itemId + "]");
        boolean hasIpVoted = voteDatabase.contains(ipVoteKey);

        // Falls bereits mindestens eine der Sperrbedingungen zutrifft, wird eine entsprechende Meldung gebaut und
        // der Response mit StatusCode und einem Fehlertext zurueckgegeben
        if (hasCookie || hasIpVoted) {
            String grund = hasCookie ? "Cookie-Erkennung" : "IP-Erkennung (" + clientIp + ")";
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Gesperrt via " + grund + "! Sie haben fuer Item " + itemId + " bereits abgestimmt.");
        } else {

            // 3. Erfolg/Klick in der "Datenbank" persistieren
            voteDatabase.add(ipVoteKey);

            // 4. Neuen Cookie generieren, im Header anhaengen und im Body eine Erfolgsmeldung mitsenden
            String newCookieValue = votedCookie + "[" + itemId + "]";
            ResponseCookie cookie = ResponseCookie.from("voted_items", newCookieValue)
                    .path("/")
                    .maxAge(86400) // 1 Tag gueltig
                    .httpOnly(true) // Erhoehte Sicherheit: JS kann den Cookie nicht auslesen
                    .build();

            return ResponseEntity.ok()
                    .header(HttpHeaders.SET_COOKIE, cookie.toString())
                    .body("Erfolg! Stimme fuer Item " + itemId + " gezaehlt. (Registrierte IP: " + clientIp + ")");
        }
    }
}