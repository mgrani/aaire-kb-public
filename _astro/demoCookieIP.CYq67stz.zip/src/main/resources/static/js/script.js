async function sendVote(itemId) {
    const logDiv = document.getElementById("responseLog");

    try {
        // HINWEIS: Da Frontend und Backend auf demselben Server laufen,
        // reicht ein relativer Pfad. Der Browser sendet Cookies AUTOMATISCH mit!
        const response = await fetch(`/api/demo/vote/${itemId}`, {
            method: 'POST'
        });

        const text = await response.text();
        logDiv.style.display = "block";

        if (response.ok) {
            logDiv.className = "success";
            logDiv.innerText = text;
        } else {
            logDiv.className = "error";
            logDiv.innerText = text;
        }
    } catch (error) {
        logDiv.className = "error";
        logDiv.innerText = "Netzwerkfehler: Server laeuft nicht?";
        logDiv.style.display = "block";
    }
}

document.getElementById("btn1").addEventListener("click", () => {sendVote(1)})
document.getElementById("btn2").addEventListener("click", () => {sendVote(2)})