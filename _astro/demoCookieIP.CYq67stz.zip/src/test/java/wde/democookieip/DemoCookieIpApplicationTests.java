package wde.democookieip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCookieIpApplicationTests {

    @Test
    void contextLoads() {
    }

}
