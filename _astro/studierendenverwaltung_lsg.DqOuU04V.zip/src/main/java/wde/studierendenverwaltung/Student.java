package wde.studierendenverwaltung;

public class Student {
    private Long id;
    private String name;
    private String subject;


    public Student() {
    }

    public Student(Long id, String name, String subject) {
        this.id = id;
        this.name = name;
        this.subject = subject;
    }

    // Getter und Setter
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
