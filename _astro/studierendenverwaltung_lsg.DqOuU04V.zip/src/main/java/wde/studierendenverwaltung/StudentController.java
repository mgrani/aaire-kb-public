package wde.studierendenverwaltung;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController // Kennzeichnet die Klasse als REST-Controller
@RequestMapping("/students") // Alle Endpunkte in dieser Klasse starten mit /students
public class StudentController {

    // Das Repository wird per  Injection automatisch von Spring bereitgestellt
    private final StudentRepository repo;

    public StudentController(StudentRepository repo) {
        this.repo = repo;
    }

    // GET ALL: Alle Studierenden abrufen
    @GetMapping("")
    public ResponseEntity<List<Student>> getAll() {
        return ResponseEntity.ok(repo.findAll());
    }

    // GET BY ID: Einzelnen Studierenden suchen
    @GetMapping("/{id}")
    public ResponseEntity<Student> getById(@PathVariable Long id) {
        // @PathVariable liest die ID aus der URL
        // Suchen im Repository liefert ein Optional (kann leer sein)
        Optional<Student> studentOpt = repo.findById(id);

        if (studentOpt.isPresent()) {
            // Wenn gefunden: Status 200 OK und das Student-Objekt im Body
            return ResponseEntity.ok(studentOpt.get());
        } else {
            // Wenn nicht gefunden: Status 404 Not Found
            return ResponseEntity.notFound().build();
        }
    }

    // POST: Neuen Studierenden anlegen
    @PostMapping("")
    public ResponseEntity<Student> create(@RequestBody Student student) {

        Student savedStudent = repo.save(student);

        // Erstellen der Location-URI fuer den Response-Header (z.B. /students/3)
        URI location = URI.create("/students/" + savedStudent.getId());

        // Status 201 Created zurueckgeben, inklusive Location-Header und dem gespeicherten Objekt
        return ResponseEntity.created(location).body(savedStudent);
    }

    // DELETE: Studierenden loeschen
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        // @PathVariable liest die ID aus der URL
        repo.deleteById(id);

        // Status 204 No Content (Erfolgreich geloescht, keine Daten im Body)
        return ResponseEntity.noContent().build();
    }
}
