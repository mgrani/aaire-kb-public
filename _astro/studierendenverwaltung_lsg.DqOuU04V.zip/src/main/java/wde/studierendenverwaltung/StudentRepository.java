package wde.studierendenverwaltung;

import org.springframework.stereotype.Repository;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;



/*
* WICHTIGER HINWEIS:
* Diese Implementierung einer Repository-Klasse entspricht absichtlich nicht den Vorgaben und 
* soll somit NICHT als Musterlösung gesehen werden! Diese Aufgabe bezieht sich auf 
* die Implementierung des Controllers. 
* Diese Klasse dient lediglich dazu, die notwendigen Daten möglichst unkompliziert
* zur Verfügung zu stellen und den Umfang des Projekts möglichst klein zu halten. 
* Für eine saubere Implementierung von Repository- und Entity-Klassen sei
* auf die entsprechenden Übungsaufgaben verwiesen!
*/
@Repository
public class StudentRepository {
    // Simuliert die Datenbank-Tabelle
    private final Map<Long, Student> database = new ConcurrentHashMap<>();
    private long idSequence = 1;

    public StudentRepository() {
        // Feste Testdaten beim Start erzeugen
        save(new Student(null, "Max Mustermann", "Informatik"));
        save(new Student(null, "Anna Mueller", "Data Science"));
    }

    public List<Student> findAll() {
        return new ArrayList<>(database.values());
    }

    public Optional<Student> findById(Long id) {
        return Optional.ofNullable(database.get(id));
    }

    public Student save(Student student) {
        if (student.getId() == null) {
            student.setId(idSequence++);
        }
        database.put(student.getId(), student);
        return student;
    }

    public void deleteById(Long id) {
        database.remove(id);
    }
}