package wde.studierendenverwaltung;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudierendenverwaltungApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudierendenverwaltungApplication.class, args);
    }

}
