package wde.studierendenverwaltung;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudierendenverwaltungApplicationTests {

    @Test
    void contextLoads() {
    }

}
