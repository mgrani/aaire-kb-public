package wde.studierendenverwaltung;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;


public class StudentController {

    // Das Repository wird per Injection automatisch von Spring bereitgestellt


    // GET ALL: Alle Studierenden abrufen


    // GET BY ID: Einzelnen Studierenden suchen


    // POST: Neuen Studierenden anlegen


    // DELETE: Studierenden loeschen

}
