package wde.testdemo;

import org.springframework.stereotype.Service;

@Service
public class StudentService {
    public boolean enroll(Student student) {
        if (student.getName() == null || student.getName().trim().isEmpty()) {
            System.out.println("Student name is null or empty");
            throw new IllegalArgumentException("Name darf nicht leer sein!");
        }
        System.out.println("Student enrollment ist: " + student.getName());
        return true;
    }
}
