package wde.testdemo;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class StudentTestA_commented {

    private final StudentService service = new StudentService();

    @Test // Markiert die Methode als ausfuehrbaren JUnit-Test
    void enroll_withValidName_returnsTrue() {
        Student s = new Student("Max Mustermann");
        // Prueft, ob der Service bei einem gueltigen Namen 'true' zurueckgibt
        assertTrue(service.enroll(s));
    }

    @Test
    void enroll_withEmptyName_throwsException() {
        Student s = new Student("");
        // Prueft, ob beim Uebergeben eines leeren Namens genau diese Exception geworfen wird
        assertThrows(IllegalArgumentException.class, () -> service.enroll(s));
    }
}