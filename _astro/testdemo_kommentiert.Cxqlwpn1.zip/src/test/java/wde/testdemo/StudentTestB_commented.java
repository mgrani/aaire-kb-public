package wde.testdemo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(StudentController.class) // Startet NUR den Web-Layer (Controller), aber keine Services oder Datenbanken
public class StudentTestB_commented {

    @Autowired
    private MockMvc mockMvc; // Erlaubt das Testen von HTTP-Endpunkten, ohne einen echten Server zu starten

    @MockitoBean // Erstellt eine Attrappe (Mock) des Services und injiziert diese in den Spring-Kontext
    private StudentService service;

    @Test
    void createStudent_withValidJson_returnsOk() throws Exception {
        // Mock-Verhalten definieren: Wenn die enroll-Methode mit irgendeinem Student-Objekt aufgerufen wird, gib 'true' zurueck
        when(service.enroll(any(Student.class))).thenReturn(true);

        // Einen simulierten POST-Request an "/students" senden
        mockMvc.perform(post("/students")
                        .contentType(MediaType.APPLICATION_JSON) // Wir schicken JSON-Daten
                        .content("{\"name\": \"Anna\"}")) // Der Request-Body
                .andExpect(status().isOk()); // Wir erwarten als HTTP-Antwort den Status 200 (OK)
    }
}