package wde.testdemo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;

// Faehrt den kompletten Spring-IoC-Container hoch und startet einen echten Webserver auf einem zufaelligen Port
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class StudentTestC_commented {

    @Autowired
    private TestRestTemplate restTemplate; // Ein echter HTTP-Client, der Netzwerkanfragen an den gestarteten Server sendet

    @Test
    void entireApplicationFlow_worksCorrectly() {
        Student s = new Student("Tom");

        // Fuehrt einen echten HTTP-POST-Request gegen die laufende Applikation aus
        ResponseEntity<String> response = restTemplate.postForEntity("/students", s, String.class);

        // Ueberprueft, ob der Server mit 200 OK antwortet
        assertEquals(HttpStatus.OK, response.getStatusCode());
        // Ueberprueft, ob der Controller den korrekten String im Body zurueckgibt
        assertEquals("Erfolgreich immatrikuliert", response.getBody());
    }
}