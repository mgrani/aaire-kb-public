package wde.waehrungsrechner_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WaehrungsrechnerSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(WaehrungsrechnerSpringApplication.class, args);
    }

}
