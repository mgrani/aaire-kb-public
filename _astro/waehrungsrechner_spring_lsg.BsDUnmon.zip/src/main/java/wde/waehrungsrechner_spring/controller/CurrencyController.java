package wde.waehrungsrechner_spring.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import wde.waehrungsrechner_spring.dto.ConversionDTO;
import wde.waehrungsrechner_spring.service.CurrencyService;

@RestController
@RequestMapping("/api/currency")
public class CurrencyController {

    private final CurrencyService currencyService;

    public CurrencyController(CurrencyService currencyService) {
        this.currencyService = currencyService;
    }

    @GetMapping("/convert")
    public ResponseEntity<?> convert(@RequestParam Double amount, @RequestParam String targetCurrency) {

        ConversionDTO dto = currencyService.convert(amount, targetCurrency);

        if(dto == null) {
            return ResponseEntity
                    .badRequest()
                    .body("Währung nicht gefunden");
        }

        return ResponseEntity.ok(dto);
    }
}