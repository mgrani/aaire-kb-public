package wde.waehrungsrechner_spring.dto;

public class ConversionDTO {

    private Double amount;
    private String targetCurrency;
    private Double result;

    public ConversionDTO(Double amount, String targetCurrency, Double result) {
        this.amount = amount;
        this.targetCurrency = targetCurrency;
        this.result = result;
    }

    public Double getAmount() {
        return amount;
    }

    public String getTargetCurrency() {
        return targetCurrency;
    }

    public Double getResult() {
        return result;
    }
}