package wde.waehrungsrechner_spring.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "exchange_rates")
public class ExchangeRate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String currency;

    private Double rate;

    public ExchangeRate() {
    }

    public ExchangeRate(String currency, Double rate) {
        this.currency = currency;
        this.rate = rate;
    }

    public Long getId() {
        return id;
    }

    public String getCurrency() {
        return currency;
    }

    public Double getRate() {
        return rate;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setRate(Double rate) {
        this.rate = rate;
    }
}
