package wde.waehrungsrechner_spring.service;

import org.springframework.stereotype.Service;
import wde.waehrungsrechner_spring.dto.ConversionDTO;
import wde.waehrungsrechner_spring.entity.ExchangeRate;
import wde.waehrungsrechner_spring.repository.ExchangeRateRepository;

import java.util.Optional;

@Service
public class CurrencyService {

    private final ExchangeRateRepository repository;

    public CurrencyService(ExchangeRateRepository repository) {
        this.repository = repository;
    }

    public ConversionDTO convert(Double amount, String targetCurrency) {

        Optional<ExchangeRate> optRate = repository.findByCurrency(targetCurrency);

        ExchangeRate rate;

        if (optRate.isPresent()) {
            rate = optRate.get();
        } else {
            rate = null;
        }

        if (rate == null) {
            return null;
        } else {
            Double converted = amount * rate.getRate();
            return new ConversionDTO(amount, targetCurrency, converted);
        }
    }
}