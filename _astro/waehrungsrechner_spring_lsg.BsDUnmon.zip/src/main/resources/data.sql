INSERT INTO exchange_rates(currency, rate)
VALUES ('USD', 1.14);

INSERT INTO exchange_rates(currency, rate)
VALUES ('CHF', 0.93);