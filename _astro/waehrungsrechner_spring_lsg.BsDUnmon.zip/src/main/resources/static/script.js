const amountEl = document.getElementById('amount');
const currencyEl = document.getElementById('targetCurrency');
const resultEl = document.getElementById('result');


async function convert() {
    const amount = amountEl.value;
    const target = currencyEl.value;

    if (!amount || amount <= 0) {
        resultEl.innerText = "Bitte Betrag eingeben";
        return;
    }

    try {
        // Dein Spring Boot Endpoint
        const url =
            `/api/currency/convert?amount=${amount}&targetCurrency=${target}`;

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error("Backend Fehler");
        }


        const data = await response.json();

        resultEl.innerHTML =
            `${data.amount} EUR =
             ${data.result.toFixed(2)}
             ${data.targetCurrency}`;

    } catch (error) {
        resultEl.innerText = "Fehler beim Laden der Daten.";
        console.error(error);
    }
}


// Event-Listener für automatische Aktualisierung
amountEl.addEventListener('input', convert);
currencyEl.addEventListener('change', convert);