function isValidLuhn(number) {
    let sum = 0;
    let isSecond = false;
    for (let i = number.length - 1; i > -1; i--) {
        let d = Number(number[i]);
        console.log(d);
        if (isSecond) { 
            d *= 2;
            if (d > 9) {
                d = d - 9
            }
        } 
        sum += d;
        isSecond = !isSecond;
    }
    return sum % 10 === 0;
}

//console.log(isValidLuhn('4532015112830366')); // true
//console.log(isValidLuhn('1234567890123456')); // false


function generateOutput() {

    const input = document.getElementById('input').value;
    const output = document.getElementById('output');
    const num = Number(input);
    let outputText = "";

    if (input == "" || Number.isNaN(num)) {
        outputText = "Fehlerhafte Eingabe!"
    } else {
        if (isValidLuhn(input)) {
            outputText = "Gültig!"
        } else {
            outputText = "Ungültig!"
        }
    }

    output.textContent = outputText;
}