const btn = document.getElementById('toggle-theme');

btn.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');

    if (isDark) {
        btn.textContent = 'Light Mode';
    } else {
        btn.textContent = 'Dark Mode'
    }
});
