const amountEl = document.getElementById('amount');
const currencyEl = document.getElementById('targetCurrency');
const resultEl = document.getElementById('result');

// --- Lücke ergänzen ---
_______ function convert() {
    const amount = amountEl.value;
    const target = currencyEl.value;

    if (!amount || amount <= 0) {
        resultEl.innerText = "Bitte Betrag eingeben";
        return;
    }

    // --- START: Hier ergänzen  ---

    // --- ENDE ---
}

// --- START: ---
// Event-Listener für automatische Aktualisierung


// --- ENDE ---