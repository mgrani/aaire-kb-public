package wde.studierendenverwaltung;

import org.springframework.stereotype.Repository;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class StudentRepository {
    // Simuliert die Datenbank-Tabelle
    private final Map<Long, Student> database = new ConcurrentHashMap<>();
    private long idSequence = 1;

    public StudentRepository() {
        // Feste Testdaten beim Start erzeugen
        save(new Student(null, "Max Mustermann", "Informatik"));
        save(new Student(null, "Anna Mueller", "Data Science"));
    }

    public List<Student> findAll() {
        return new ArrayList<>(database.values());
    }

    public Optional<Student> findById(Long id) {
        return Optional.ofNullable(database.get(id));
    }

    public Student save(Student student) {
        if (student.getId() == null) {
            student.setId(idSequence++);
        }
        database.put(student.getId(), student);
        return student;
    }

    public void deleteById(Long id) {
        database.remove(id);
    }
}