package wde.commandlinerunnerdemo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

// TODO: Implementieren Sie das CommandLineRunner Interface
public class DataInitializer {

    // TODO: Binden Sie das ProductRepository per Dependency Injection ein

    @Override
    public void run(String... args) throws Exception {

        // TODO: Fügen Sie System.out.println-Ausgaben hinzu, um den Start zu visualisieren.
    }
}
