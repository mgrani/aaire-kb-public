package wde.testdemo;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class StudentTestA {

    private final StudentService service = new StudentService();

    @Test
    void enroll_withValidName_returnsTrue() {
        Student s = new Student("Max Mustermann");
        assertTrue(service.enroll(s));
    }

    @Test
    void enroll_withEmptyName_throwsException() {
        Student s = new Student("");
        assertThrows(IllegalArgumentException.class, () -> service.enroll(s));
    }
}