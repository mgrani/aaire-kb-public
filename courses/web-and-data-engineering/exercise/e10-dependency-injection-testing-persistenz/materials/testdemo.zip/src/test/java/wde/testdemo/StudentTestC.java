package wde.testdemo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class StudentTestC {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void entireApplicationFlow_worksCorrectly() {
        Student s = new Student("Tom");

        ResponseEntity<String> response = restTemplate.postForEntity("/students", s, String.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Erfolgreich immatrikuliert", response.getBody());
    }
}