const API_URL = "./data/example.json";

async function fetchData() {
    const dataArea = document.getElementById("data_area");

    try {
        const response = await fetch(API_URL);

        if (!response.ok) {
            throw new Error("Fehler beim Abrufen der Daten");
        }

        const data = await response.json();
        console.log("Daten erfolgreich geladen:", data);

        if (!data.length) {
            dataArea.innerHTML = "<p>Keine Daten gefunden.</p>";
            return;
        }

        const item = data[0];

        dataArea.innerHTML = `
            <h2>ID: ${item.id}</h2>
            <p>${item.text}</p>
        `;
    } catch (error) {
        console.error("Fehler beim Laden der Daten:", error);
        dataArea.innerHTML = "<p>Fehler beim Laden der Daten.</p>";
    }
}

const dataBtn = document.getElementById("btn_add_data");
dataBtn.addEventListener("click", fetchData);